from mysql import connector
# import MySQLdb as connector
ssl = {'sha_256': '11 9B F1 AC 7E 10 0E 9D B9 B7 B6 80 0C 0D C1 17 A6 1D FA 66 53 C1 0F 6A 74 D8 D9 09 07 E9 A3 E7',
       'cookie_key':'def00000542d98879c30e385c4dcaaa9392ad1658e4230902474c08618d337cfbed1ba895a5f885da2f7592bab0508472744d284401289964eb8aa9ab23d2a8b2842f9c0',
        'sha_1': '34 C2 17 0E 8A BD 47 CF 14 05 3E D6 2F 2D A9 A1 07 4F 11 06'
       }
user = 'apollocl_pres187'
password = '7pM9R!Sn0)'
user1 = 'apollocl_Python_App'
pass1 = 'Mr03056842507'
cloud = 'apollocl_cloud'

ca_certificate = '/Users//mubashir//Desktop//Business_Drive//Freelauncing//Cloud_Storage_Project//cacert.pem'
ca_certificate1 = '/Users//mubashir//Desktop//Business_Drive//Freelauncing//Cloud_Storage_Project//apollocloud_me_aeb22_3d371_1632009599_3c5596a7bab455e99a99e843188de508.crt'
ssl_private_key = '/Users//mubashir//Desktop//Business_Drive//Freelauncing//aeb22_3d371_78e2d10da8f9467ebe7a21f91ad0f8c8.key'
shared_IP = '185.146.22.237'
domain = 'https://apollocloud.me'
conn = connector.connect(host=shared_IP, user=user1, password = pass1,
                         database=cloud,
                         ssl_cert=ca_certificate1,ssl_key= ssl_private_key,#ssl_ca = ca_certificate
                         )
print(conn)
if conn:
    print("Connected")
else:
    print("Not Connected")