


Images = ["output-onlinepngtools.png","edit-user-24.png","key-3-24.png","cloud-upload-24.png","cloud-download-24.png"]
TopColor = "#0384fc"
BackColor = "blue"
ForColor = "white"
Normal_Font = ("Times 14")
full_width = 900
full_height = 700

width = 300
height = 350
x = 900//2 - width//2
y = 700//2 - height//2
