SELECT = "SELECT"
UPDATE = "UPDATE"
DELETE = "DELETE"
INSERT = "INSERT"
CREATE = "CREATE"
LoginTable = {
    'database': "LoginDetails.db",
    'table': "LoginTable",
    'columns': ["Username","Password","Full_Name","Status"]
}