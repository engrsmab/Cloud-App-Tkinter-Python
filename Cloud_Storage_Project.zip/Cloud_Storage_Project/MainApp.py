
from tkinter import *
from tkmacosx import Button

import Backend
from Requirments import *

def Dashboard():
    Dash = Frame(root,bg=BackColor,width=full_width,height = full_height)
    Dash.pack()
    Dash.place(x=0,y=0)
    TopFrame = Frame(Dash,bg=TopColor,width=full_width,height=100)
    TopFrame.pack()
    TopFrame.place(x=0,y=0)
    Name = Label(TopFrame,text="Nivy",bg=TopColor,fg=ForColor,font=Normal_Font)
    Name.pack()
    Name.place(x=20,y=10)
    image = [upload,download]
    text = ["Upload","Download"]
    button = []
    X = 100


    for i in range(2):

        buttons = Button(TopFrame,bg=TopColor,fg=ForColor,relief=FLAT,image=image[i],text=text[i],compound="top")
        buttons.pack()
        buttons.place(x=X,y=40)
        button.append(buttons)
        X += 100
    Window = LabelFrame(Dash,bg=BackColor,borderwidth=5,width=full_width - 40, height=full_height - 170)
    Window.pack()
    Window.place(x=20,y=130)
    Files = False
    Num_Files = 10
    if Files == False:
        mytext = Label(Window,text="No Files to Show",bg=BackColor,fg=TopColor,font=Normal_Font)
        mytext.pack()
        mytext.place(x=380,y=250)
        Num_Files = 0
        button[1]['state'] = "disabled"
        # buttons = Button(Window, bg=BackColor, fg=TopColor, relief=FLAT, image=image[0], text=text[0], compound="top")
        # buttons.pack()
        # buttons.place(x=400, y=280)
    files = ["Total Files:",str(Num_Files)]
    X = 700
    for i in files:
        label = Label(Window,text=i,bg=BackColor,fg=ForColor,font=Normal_Font)
        label.pack()
        label.place(x=X,y=20)
        X += 100
def Logging_In(data,s):
    ans = Backend.Login(data,s)
    if ans:
        Dashboard()
def clear(event, entry):
    entry.delete(0,"end")
    entries[1]['show'] = "*"


root = Tk()

# root.geometry("500x500")
root.geometry("{}x{}".format(full_width,full_height))
root.title("Freelauncing Database")
frame = Frame(root,bg=BackColor)
frame.pack(fill=BOTH,expand=1)

logo = PhotoImage(file=Images[0])
logImg = PhotoImage(file=Images[1])
passImg = PhotoImage(file=Images[2])
upload = PhotoImage(file=Images[3])
download = PhotoImage(file=Images[4])
logo_Label = Label(root,image=logo,bg="orange")
logo_Label.pack()
logo_Label.place(x=400,y=180)
loginFrame = Frame(frame,bg="orange",width=width,height=height)
loginFrame.pack()
loginFrame.place(x=x,y=y)

loginImg = [logImg,passImg]
y = 120
entries = []
entry_label = ["Username","Passward"]
j = 0
for i in loginImg:
    lbl = Label(loginFrame,image=i,bg="red")
    lbl.pack()
    lbl.place(x=50,y=y)
    entry = Entry(loginFrame,width=20,font=("Times 18"))
    entry.pack()
    entry.place(x=80,y=y)
    entry.insert(0,entry_label[j])
    entry.bind("<Button-1>",lambda  event, ent = entry: clear(event,ent))
    entries.append(entry)
    y += 50
    j += 1

check = IntVar()
logged_in = Checkbutton(loginFrame,text="Remember me",bg="orange", variable=check)
logged_in.pack()
logged_in.place(x=60,y=210)
loginBtn = Button(loginFrame,text="Login",width=200,font=("Times 18"),bg="red",fg=ForColor,command=lambda entries=entries,check=check:Logging_In(entries,check))
loginBtn.pack()
loginBtn.place(x=60,y=250)


root.mainloop()
