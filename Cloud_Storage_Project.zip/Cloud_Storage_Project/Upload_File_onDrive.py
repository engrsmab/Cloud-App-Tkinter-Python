import json
import requests

headers = {"Authorization": "Bearer ya29.a0ARrdaM-pWxYZYNrzB0zsB_wJl_AcrIi9nlqdZBMOfFmIfRLuN2avBDquc4zYSls42v2yiSH4YH3ZlIFjPYV9oeiN9pJzg2oZieKweuXICUkWMfJlPTYoMDYCYqmCjnE6r4mQeAz4fTU2XhKAeWzTaPliO7no"}
para = {
    "name": "Image.png",
}
files = {
    'data': ('metadata', json.dumps(para), 'application/json; charset=UTF-8'),
    'file': open("./edit-user-24.png", "rb")
}
r = requests.post(
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
    headers=headers,
    files=files
)
print(r.text)